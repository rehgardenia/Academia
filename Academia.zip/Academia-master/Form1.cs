namespace Tarefa01
{
    public partial class Formulario : Form
    {
        public Formulario()
        {
            InitializeComponent();
        }


        private void AtivarSelecao()
        {
            if (!string.IsNullOrWhiteSpace(txt_nome.Text) &&
                !string.IsNullOrWhiteSpace(txt_email.Text) &&
                (rd_manha.Checked || rd_tarde.Checked || rd_noite.Checked))
            {
                btn_add.Enabled = true;
                btn_remove.Enabled = true;
                btn_addTodos.Enabled = true;
                btn_removeTodos.Enabled = true;

                chk_yoga.Enabled = true;
                chk_meditacao.Enabled = true;
                chk_natacao.Enabled = true;
                chk_pilates.Enabled = true;
                chk_musculacao.Enabled = true;

                lst_disponiveis.Enabled = true;
                lst_selecionadas.Enabled = true;
            }
        }
        private void btn_sair_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Deseja realmente sair?", "Confirma��o",
                                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btn_limpar_Click(object sender, EventArgs e)
        {
            txt_nome.Clear();
            txt_email.Clear();

            rd_manha.Checked = false; 
            rd_tarde.Checked = false; 
            rd_noite.Checked = false;

            lst_disponiveis.Items.Clear();
            lst_selecionadas.Items.Clear();
            lst_disponiveis.Items.AddRange(new object[] {
                "Karat�",
                "Muay Thai",
                "Jud�",
                "Capoeira",
                "Boxing",
                "Taekwondo",
                "Kung-Fu"
            });

            chk_yoga.Checked = false;
            chk_meditacao.Checked = false; 
            chk_pilates.Checked = false;
            chk_natacao.Checked = false;
            chk_musculacao.Checked = false;

            txt_qtd.Text = "0";
            txt_cortesia.Text = "0";
            txt_valor.Text = "0,00";

            btn_add.Enabled = false;
            btn_remove.Enabled = false;
            btn_addTodos.Enabled = false;
            btn_removeTodos.Enabled = false;

            chk_yoga.Enabled = false;
            chk_meditacao.Enabled = false;
            chk_natacao.Enabled = false;
            chk_pilates.Enabled = false;
            chk_musculacao.Enabled = false;

            lst_disponiveis.Enabled = false;
            lst_selecionadas.Enabled = false;

            txt_nome.Focus();

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (lst_disponiveis.SelectedItem != null)
            {
                lst_selecionadas.Items.Add(lst_disponiveis.SelectedItem);
                lst_disponiveis.Items.Remove(lst_disponiveis.SelectedItem);
                CalcularPreco();
            }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (lst_selecionadas.SelectedItem != null)
            {
                lst_disponiveis.Items.Add(lst_selecionadas.SelectedItem);
                lst_selecionadas.Items.Remove(lst_selecionadas.SelectedItem);
                CalcularPreco();
            }
        }

        private void btn_addTodos_Click(object sender, EventArgs e)
        {
            foreach (var item in lst_disponiveis.Items)
            {
                lst_selecionadas.Items.Add(item);
            }
            lst_disponiveis.Items.Clear();
            CalcularPreco();
        }

        private void btn_removeTodos_Click(object sender, EventArgs e)
        {
            foreach (var item in lst_selecionadas.Items)
            {
                lst_disponiveis.Items.Add(item);
            }
            lst_selecionadas.Items.Clear();
            CalcularPreco();
        }


        private void CalcularPreco()
        {
            int qtd = lst_selecionadas.Items.Count;
            int qtdCortesia = cortesia.Controls.OfType<CheckBox>().Count(cb => cb.Checked);
            txt_qtd.Text = qtd.ToString();
            txt_cortesia.Text = qtdCortesia.ToString();

            if (qtd == 0)
            {
                txt_valor.Text = "0,00";
                return;
            }

            decimal preco = 0;
            if (qtd <= 2) preco = 100;
            else if (qtd <= 4) preco = 150;
            else if (qtd <= 6) preco = 200;
            else preco = 250;

            // desconto da tarde
            if (rd_tarde.Checked)
                preco -= preco * 0.15m;

            txt_valor.Text = preco.ToString("F2");
        }

        private void txt_nome_Leave(object sender, EventArgs e)
        {
            AtivarSelecao();
        }

        private void txt_email_Leave(object sender, EventArgs e)
        {
            AtivarSelecao();
        }

        private void rd_manha_CheckedChanged(object sender, EventArgs e)
        {
            AtivarSelecao();
        }

        private void rd_tarde_CheckedChanged(object sender, EventArgs e)
        {
            AtivarSelecao();
        }

        private void rd_noite_CheckedChanged(object sender, EventArgs e)
        {
            AtivarSelecao();
        }

        
        private void Formulario_Load(object sender, EventArgs e)
        {
            foreach (CheckBox item in cortesia.Controls.OfType<CheckBox>())
            {
                item.CheckedChanged += CheckBox_CheckChanged!;
            }
        }

        private void CheckBox_CheckChanged(object sender, EventArgs e)
        {
            int selecionados = cortesia.Controls.OfType<CheckBox>().Count(cb => cb.Checked);

            if (selecionados > 3)
            {
                CheckBox atual = sender as CheckBox;
                atual!.Checked = false;

                MessageBox.Show("Excedeu o limite de cortesias: m�ximo 3 op��es.");
            }
            CalcularPreco();
        }
    }
}
